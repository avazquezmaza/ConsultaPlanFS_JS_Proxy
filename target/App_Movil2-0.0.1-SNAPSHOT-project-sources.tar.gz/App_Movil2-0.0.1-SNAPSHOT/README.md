
# Deploying APP_Movil/Proxy Services/Product/ConsultaPlanFS_JS_Proxy to OpenShift

## Build and deploy

To deploy APP_Movil/Proxy Services/Product/ConsultaPlanFS_JS_Proxy to OpenShift, when logged in execute

	mvn install
  